package com.niit.EshopBack;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Eshopback.dao.SupplierDAO;
import com.niit.Eshopback.model.Category;
import com.niit.Eshopback.model.Supplier;

public class SupplierTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();

		SupplierDAO supplierDAO = (SupplierDAO) context.getBean("supplierDAO");

		Supplier supplier = (Supplier) context.getBean("supplier");

		supplier.setId("SU254");

		supplier.setName("SUPName");
		supplier.setAddress("BBSR");
		System.out.println(supplier.getId());

		supplierDAO.saveOrUpdate(supplier);
		System.out.println("s3");

		System.out.println("Supllier saved successfully");

	}

}
package com.niit.EshopBack;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Eshopback.dao.ProductDAO;
import com.niit.Eshopback.model.Product;

public class ProductTest {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit");

		context.refresh();

		
		 ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
		 
		 Product product = (Product) context.getBean("product");
		  
		 product.setId("PR004");
		 
		 product.setName("Samsung");
		  
		   
		 product.setDescription("This is Samsung S4");
		 
		 product.setPrice("50000");
		 
		 product.setCategory_id("CG021");
			
		product.setSupplier_id("SU254");
		  
		  System.out.println(product.getId());
		 
		  productDAO.saveOrUpdate(product);
		
		  System.out.println("Product saved successfully");
		 

		
	}

}